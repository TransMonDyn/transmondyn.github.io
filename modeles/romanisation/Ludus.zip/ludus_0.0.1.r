# ======================================================================
#
#	Modele LUDUS - modele graphique bayesien et theorie des jeux
#
# ----------------------------------------------------------------------
#
# AF-MJO-FB
#
# version 0.0.1 - 07/01/2017
#

# ======================================================================
#
#	Panneau de controle
#
# ======================================================================


# Fichiers a lire
# ---------------
Imp_file	<- "gains_Imp.txt"
Gaul_file	<- "gains_Gaul.txt"

# Flèches
# -------

base		<- 0.4
col_imp		<- 'red'
col_gaul	<- 'green'

# Dynamique du jeu
# -----------------

dynfile	<- 'dynfile.txt'

# ======================================================================
#
#	Main
#
# ======================================================================

library(igraph)

print("", quote=FALSE)
print("------------------------------------------------------", quote=FALSE)
print("ludus:   modele graphique bayesien et theorie des jeux", quote=FALSE)
print("         pour la dynamique des interactions", quote=FALSE)
print("         entre élites romaines et gauloises", quote=FALSE)
print("------------------------------------------------------", quote=FALSE)
print("version 0.0.1, 9 janvier 2017", quote=FALSE)
print("Alain Franc, Marie-Jeanne Ouriachi, Frédérique Bertoncello", quote=FALSE)
print("Projet ANR Transmondyn", quote=FALSE)
print("Référence: voir la notice", quote=FALSE)
print("Contact: marie-jeanne.ouriachi@unice.fr", quote=FALSE)
print("------------------------------------------------------", quote=FALSE)
print("", quote=FALSE)


# Lecture des fichiers
# --------------------

Imp			<- read.table(file=Imp_file, sep='\t', dec='.', header=TRUE)
Gaul		<- read.table(file=Gaul_file, sep='\t', dec='.', header=TRUE)

n_imp		<- nrow(Imp)
n_gaul		<- ncol(Imp)-1
N			<- n_imp*n_gaul

# Vecteurs des strategies
# ------------------------

strategies_I	<- as.character(Imp[[1]])
for (i in 1:length(strategies_I)){
	item				<- strategies_I[i]
	xx					<- strsplit(item, split='_')
	new_item			<- xx[[1]][2]
	strategies_I[i]		<- new_item
}

strategies_G	<- colnames(Imp)[2:ncol(Imp)]
for (i in 1:length(strategies_G)){
	item				<- strategies_G[i]
	xx					<- strsplit(item, split='_')
	new_item			<- xx[[1]][2]
	strategies_G[i]		<- new_item
}

# construction des etats et lecture des gains
# -------------------------------------------

etats			<- rep('', n_imp*n_gaul)
gains			<- matrix(data=0, nrow=N, ncol=2)
colnames(gains)	<- c('I','G')
k				<- 0
#
for (i in 1:length(strategies_I)){
	s_I		<- strategies_I[i]
	for (j in 1:length(strategies_G)){
		s_G			<- strategies_G[j]
		#
		k			<- k+1
		etats[k]	<-paste(s_I,s_G,sep='|')
		gains[k,1]	<- Imp[i,j+1]
		gains[k,2]	<- Gaul[i,j+1]
	}
}
rownames(gains)	<- etats

print(etats, quote=FALSE)
print(gains)


# dynamique du jeu (les fleches)
# ------------------------------

Hyper	<- matrix(data=0, nrow=N, ncol=N)
for (j in 1:N){
	s_IG	<- etats[j]
	xx		<- strsplit(s_IG, split='|', fixed=TRUE)
	s_I		<- xx[[1]][1]
	s_G		<- xx[[1]][2]
	w_I		<- gains[j,1]
	w_G		<- gains[j,2]
	# Gaulois
	for (k in 1:length(strategies_G)){
		s_Gnew		<- strategies_G[k]
		s_IGnew		<- paste(s_I, s_Gnew, sep='|')
		i			<- which(etats==s_IGnew)
		gains_new	<- gains[i,2]
		if (gains_new >= w_G){
			Hyper[j,i]	<- 1
		}
	}
	# Imperatores
	for (k in 1:length(strategies_I)){
		s_Inew		<- strategies_I[k]
		s_IGnew		<- paste(s_Inew, s_G, sep='|')
		i			<- which(etats==s_IGnew)
		gains_new	<- gains[i,1]
		if (gains_new >= w_I){
			Hyper[j,i]	<- 1
		}
	}
}
diag(Hyper)	<- 0

G_dyn		<- graph.adjacency(Hyper, mode='directed')
plot(G_dyn, vertex.label=etats)

png('dynamique_du_jeu.png')
plot(G_dyn, vertex.label=etats)
#title(main="dynamique du jeu")
dev.off()



# ---------------------- Types d'equilibres ----------------------------

Imp				<- as.matrix(Imp[,2:ncol(Imp)])
rownames(Imp)	<- strategies_I
colnames(Imp)	<- strategies_G
Gaul			<- as.matrix(Gaul[,2:ncol(Gaul)])
rownames(Gaul)	<- strategies_I
colnames(Gaul)	<- strategies_G

# Equilibres de nash
# ------------------

write('----------------------------------------------', file='')
write('Equilibres de Nash', file='')
write('----------------------------------------------', file='')
write('abc|xy est un equilibre de Nash si', file='')
write('abc est la meilleure reponse imperator à xy', file='')
write('et', file='')
write('xy est la meilleure reponse des gaulois à abc', file='')
write('----------------------------------------------', file='')

Nash	<- NULL
for (i in 1:length(strategies_I)){
	for (j in 1:length(strategies_G)){
		if (Imp[i,j] == max(Imp[,j]) & Gaul[i,j] == max(Gaul[i,])){
			nash	<- paste(strategies_I[i], strategies_G[j], sep='|')
			print(nash, quote=FALSE)
			Nash	<- c(Nash, nash)
		}
	}
}

# Equilibres de Pareto
# --------------------

write('-------------------------------', file='')
write('Equilibres de Pareto', file='')
write('-------------------------------', file='')
Par	<- NULL
for (i in 1:length(strategies_I)){
	for (j in 1:length(strategies_G)){
		max_Imp		<- FALSE
		max_Gaul	<- FALSE
		sup_i	<- which(Imp[,j] > Imp[i,j])
		if (length(sup_i)>0){
			if (max(Gaul[sup_i,j]) < Gaul[i,j]){max_Imp <- TRUE}
		}
		sup_j	<- which(Gaul[i,] > Gaul[i,j])
		if (length(sup_j)>0){
			if (max(Imp[i,sup_j]) < Imp[i,j]){max_Gaul <- TRUE}
		}
		if ((max_Imp==TRUE) & (max_Gaul==TRUE)){
			pareto	<- paste(strategies_I[i], strategies_G[j], sep='|')
			print(pareto, quote=FALSE)
			Par	<- c(Par, pareto)
		}

	}
}
if (is.null(Par)==TRUE){
	write('Pas d\'equilibre de Pareto ...', file='')
}

# Diagramme des fleches avec couleur si equilibre de Nash
# --------------------------------------------------------

triangle <- function(x_from, x_to, y_from, y_to, base=1){
	#
	#
	#
	dx			<- x_to-x_from
	dy			<- y_to-y_from
	perp		<- c(-dy,dx)
	perp		<- perp/sqrt(sum(perp*perp))
	x_base_r	<- x_from + base*perp[1]/2
	y_base_r	<- y_from + base*perp[2]/2
	x_base_l	<- x_from - base*perp[1]/2
	y_base_l	<- y_from - base*perp[2]/2
	#
	return(cbind(c(x_base_l, x_to, x_base_r), c(y_base_l, y_to, y_base_r)))
}

xy	<- layout.fruchterman.reingold(G_dyn)
#x11() ; plot(xy, xlab='', pch='n', ylab='', axes=FALSE)
#		#
#		for (i in 1:(nrow(Hyper)-1)){
#			for(j in (i+1):ncol(Hyper)){
#				if (Hyper[i,j]==1){
#					lines(xy[c(i,j),], type='l', col='blue')
#				}
#			}
#		}
#		points(xy, pch=16, col='white', cex=5)
#		if (length(Nash) > 0){
#			for (i in 1:length(Nash)){
#				k	<- which(etats==Nash[i])
#				x	<- xy[k,1]
#				y	<- xy[k,2]
#				points(x,y, pch=16, col='yellow', cex=5)
#			}
#		}
#		text(xy, labels=etats, cex=0.7)

x11() ; plot(xy, xlab='', type='n', ylab='', axes=FALSE)
		#
		for (k in 1:N){
			state	<- etats[k]
			xx		<- strsplit(state, split='|', fixed=TRUE)
			state_i	<- xx[[1]][1]
			state_g	<- xx[[1]][2]
			# Choix des gaulois
			k_i		<- which(strategies_I==state_i)
			k_j		<- which(Gaul[k_i,]==max(Gaul[k_i,]))
			for (g in k_j){
				to_j	<- colnames(Gaul)[g]
				if (to_j != state_g){
					arr		<- paste(state_i, to_j, sep='|')
					k_arr	<- which(etats==arr)
					#lines(xy[c(k,k_arr),], type='l', col='green')
					tr	<- triangle(xy[k,1], xy[k_arr,1], xy[k,2], xy[k_arr,2], base=base)
					#print(tr)
					polygon(tr, col=col_gaul)
				}
			}
			# Choix des imperatores
			k_j		<- which(strategies_G==state_g)
			k_i		<- which(Imp[,k_j]==max(Imp[,k_j]))
			for (ii in k_i){
				to_i	<- rownames(Imp)[ii]
				if (to_i != state_i){
					arr		<- paste(to_i, state_g, sep='|')
					k_arr	<- which(etats==arr)
					#lines(xy[c(k,k_arr),], type='l', col='red')
					tr	<- triangle(xy[k,1], xy[k_arr,1], xy[k,2], xy[k_arr,2], base=base)
					#print(tr)
					polygon(tr, col=col_imp)
				}
			}
		}
		# Affichjage des noeuds
		points(xy, pch=16, col='white', cex=5)
		if (length(Nash) > 0){
			for (i in 1:length(Nash)){
				k	<- which(etats==Nash[i])
				x	<- xy[k,1]
				y	<- xy[k,2]
				points(x,y, pch=16, col='yellow', cex=5)
			}
		}
		if (length(Par) > 0){
			for (i in 1:length(Par)){
				k	<- which(etats==Par[i])
				x	<- xy[k,1]
				y	<- xy[k,2]
				points(x,y, pch=16, col='cyan', cex=5)
			}
		}
		text(xy, labels=etats, cex=0.7)
		#points(xy, pch='o', col='blue', cex=5)

png('strategies_optimales.png')
plot(xy, xlab='', type='n', ylab='', axes=FALSE)
		#
		for (k in 1:N){
			state	<- etats[k]
			xx		<- strsplit(state, split='|', fixed=TRUE)
			state_i	<- xx[[1]][1]
			state_g	<- xx[[1]][2]
			# Choix des gaulois
			k_i		<- which(strategies_I==state_i)
			k_j		<- which(Gaul[k_i,]==max(Gaul[k_i,]))
			for (g in k_j){
				to_j	<- colnames(Gaul)[g]
				if (to_j != state_g){
					arr		<- paste(state_i, to_j, sep='|')
					k_arr	<- which(etats==arr)
					#lines(xy[c(k,k_arr),], type='l', col='green')
					tr	<- triangle(xy[k,1], xy[k_arr,1], xy[k,2], xy[k_arr,2], base=base)
					#print(tr)
					polygon(tr, col=col_gaul)
				}
			}
			# Choix des imperatores
			k_j		<- which(strategies_G==state_g)
			k_i		<- which(Imp[,k_j]==max(Imp[,k_j]))
			for (ii in k_i){
				to_i	<- rownames(Imp)[ii]
				if (to_i != state_i){
					arr		<- paste(to_i, state_g, sep='|')
					k_arr	<- which(etats==arr)
					#lines(xy[c(k,k_arr),], type='l', col='red')
					tr	<- triangle(xy[k,1], xy[k_arr,1], xy[k,2], xy[k_arr,2], base=base)
					#print(tr)
					polygon(tr, col=col_imp)
				}
			}
		}
		# Affichjage des noeuds
		points(xy, pch=16, col='white', cex=5)
		if (length(Nash) > 0){
			for (i in 1:length(Nash)){
				k	<- which(etats==Nash[i])
				x	<- xy[k,1]
				y	<- xy[k,2]
				points(x,y, pch=16, col='yellow', cex=5)
			}
		}
		if (length(Par) > 0){
			for (i in 1:length(Par)){
				k	<- which(etats==Par[i])
				x	<- xy[k,1]
				y	<- xy[k,2]
				points(x,y, pch=16, col='cyan', cex=5)
			}
		}
		text(xy, labels=etats, cex=0.7)
dev.off()

# ---------------------------------------------------
# Dynamique du jeu : evolution des gains (nouveau v9)
# ---------------------------------------------------


write('Dynamique du jeu', file=dynfile)
write(date(), file=dynfile, append=TRUE)
write('--------------------------------------------', file=dynfile, append=TRUE)
for (i in 1:N){
	strat	<- etats[i]
	# identification des strategies et des gains
	xx		<- strsplit(strat, split='|', fixed=TRUE)
	state_i	<- xx[[1]][1]
	state_g	<- xx[[1]][2]
	gains_i	<- gains[i,1]
	gains_g	<- gains[i,2]
	ii		<- which(strategies_I==state_i)
	jj		<- which(strategies_G==state_g)
	write('------------------------------------------', file=dynfile, append=TRUE)
	write(paste(state_i, state_g, '', gains_i, gains_g, sep='\t'), file=dynfile, append=TRUE)
	write(paste('', '----------------------------------', sep='\t'), file=dynfile, append=TRUE)
	# choix des imperatores
	new_states_i	<- which(Imp[,jj] > Imp[ii,jj])
	if (length(new_states_i)>0){
		for(new_i in new_states_i){
			new_state_i	<- strategies_I[new_i]
			new_state	<- paste(new_state_i, state_g, sep='|')
			k			<- which(etats==new_state)
			new_gain_i	<- gains[k,1]
			new_gain_g	<- gains[k,2]
			write(paste('','I',new_state_i, new_gain_i, new_gain_g, sep='\t'), file=dynfile, append=TRUE)
		}
	}
	# choix des gaulois
	new_states_g	<- which(Gaul[ii,] > Gaul[ii,jj])
	if (length(new_states_g)>0){
		for(new_g in new_states_g){
			new_state_g	<- strategies_G[new_g]
			new_state	<- paste(state_i, new_state_g, sep='|')
			k			<- which(etats==new_state)
			new_gain_i	<- gains[k,1]
			new_gain_g	<- gains[k,2]
			write(paste('','G',new_state_g, new_gain_i, new_gain_g, sep='\t'), file=dynfile, append=TRUE)
		}
	}
}


